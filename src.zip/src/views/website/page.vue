<template>
  <div>
    <main-layout />
  </div>
</template>

<script>
  import MainLayout from './mainlayout'
  export default {
    data () {
      return {
      }
    },
    components: {MainLayout}
  }
</script>
